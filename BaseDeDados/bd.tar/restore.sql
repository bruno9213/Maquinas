--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.6 (Ubuntu 11.6-1.pgdg18.04+1)
-- Dumped by pg_dump version 11.6 (Ubuntu 11.6-1.pgdg18.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE bdptda;
--
-- Name: bdptda; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE bdptda WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'pt_PT.UTF-8' LC_CTYPE = 'pt_PT.UTF-8';


ALTER DATABASE bdptda OWNER TO postgres;

\connect bdptda

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: dadosobjetos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dadosobjetos (
    id integer NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    velocidade integer NOT NULL,
    sentido character varying(255) NOT NULL,
    id_type integer NOT NULL,
    id_radar integer NOT NULL
);


ALTER TABLE public.dadosobjetos OWNER TO postgres;

--
-- Name: entidades; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.entidades (
    id integer NOT NULL,
    nome character varying(255) NOT NULL,
    "user" character varying(255) NOT NULL,
    mail character varying(255) NOT NULL,
    type_entidadeid integer NOT NULL
);


ALTER TABLE public.entidades OWNER TO postgres;

--
-- Name: estado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estado (
    id integer NOT NULL,
    velodade integer NOT NULL,
    "descrição" character varying(255) NOT NULL
);


ALTER TABLE public.estado OWNER TO postgres;

--
-- Name: sentido1_last_10; Type: MATERIALIZED VIEW; Schema: public; Owner: postgres
--

CREATE MATERIALIZED VIEW public.sentido1_last_10 AS
 SELECT count(*) AS "Contagem",
    avg(dadosobjetos.velocidade) AS "Velocidade Media",
    max(dadosobjetos.velocidade) AS "Velocidade Maxima",
    min(dadosobjetos.velocidade) AS "Velocidade Minima"
   FROM public.dadosobjetos
  WHERE ((dadosobjetos."timestamp" >= ((now())::timestamp without time zone - '00:10:00'::interval)) AND (dadosobjetos.id_type = ANY (ARRAY[2, 3, 4])) AND ((dadosobjetos.sentido)::text = '1'::text))
  WITH NO DATA;


ALTER TABLE public.sentido1_last_10 OWNER TO postgres;

--
-- Name: estatisticas_sentido_1; Type: MATERIALIZED VIEW; Schema: public; Owner: postgres
--

CREATE MATERIALIZED VIEW public.estatisticas_sentido_1 AS
 SELECT sentido1_last_10."Contagem",
    sentido1_last_10."Velocidade Media",
    sentido1_last_10."Velocidade Maxima",
    sentido1_last_10."Velocidade Minima",
        CASE
            WHEN (sentido1_last_10."Contagem" = 0) THEN 'pouco trânsito'::text
            WHEN (sentido1_last_10."Velocidade Media" >= (50)::numeric) THEN 'pouco trânsito'::text
            WHEN ((sentido1_last_10."Velocidade Media" < (50)::numeric) AND (sentido1_last_10."Velocidade Media" >= (30)::numeric)) THEN 'trânsito moderado'::text
            WHEN ((sentido1_last_10."Velocidade Media" < (30)::numeric) AND (sentido1_last_10."Velocidade Media" >= (10)::numeric)) THEN 'muito trânsito'::text
            WHEN ((sentido1_last_10."Velocidade Media" < (10)::numeric) AND (sentido1_last_10."Velocidade Media" >= (0)::numeric)) THEN 'congestionamento extremo'::text
            ELSE 'erro'::text
        END AS "Estado do Transito"
   FROM public.sentido1_last_10
  GROUP BY sentido1_last_10."Velocidade Media", sentido1_last_10."Contagem", sentido1_last_10."Velocidade Maxima", sentido1_last_10."Velocidade Minima"
  WITH NO DATA;


ALTER TABLE public.estatisticas_sentido_1 OWNER TO postgres;

--
-- Name: sentido2_last_10; Type: MATERIALIZED VIEW; Schema: public; Owner: postgres
--

CREATE MATERIALIZED VIEW public.sentido2_last_10 AS
 SELECT count(*) AS "Contagem",
    abs(avg(dadosobjetos.velocidade)) AS "Velocidade Media",
    max(abs(dadosobjetos.velocidade)) AS "Velocidade Maxima",
    min(abs(dadosobjetos.velocidade)) AS "Velocidade Minima"
   FROM public.dadosobjetos
  WHERE ((dadosobjetos."timestamp" >= ((now())::timestamp without time zone - '00:10:00'::interval)) AND (dadosobjetos.id_type = ANY (ARRAY[2, 3, 4])) AND ((dadosobjetos.sentido)::text = '0'::text))
  WITH NO DATA;


ALTER TABLE public.sentido2_last_10 OWNER TO postgres;

--
-- Name: estatisticas_sentido_2; Type: MATERIALIZED VIEW; Schema: public; Owner: postgres
--

CREATE MATERIALIZED VIEW public.estatisticas_sentido_2 AS
 SELECT sentido2_last_10."Contagem",
    sentido2_last_10."Velocidade Media",
    sentido2_last_10."Velocidade Maxima",
    sentido2_last_10."Velocidade Minima",
        CASE
            WHEN (sentido2_last_10."Contagem" = 0) THEN 'pouco trânsito'::text
            WHEN (sentido2_last_10."Velocidade Media" >= (50)::numeric) THEN 'pouco trânsito'::text
            WHEN ((sentido2_last_10."Velocidade Media" < (50)::numeric) AND (sentido2_last_10."Velocidade Media" >= (30)::numeric)) THEN 'trânsito moderado'::text
            WHEN ((sentido2_last_10."Velocidade Media" < (30)::numeric) AND (sentido2_last_10."Velocidade Media" >= (10)::numeric)) THEN 'muito trânsito'::text
            WHEN ((sentido2_last_10."Velocidade Media" < (10)::numeric) AND (sentido2_last_10."Velocidade Media" >= (0)::numeric)) THEN 'congestionamento extremo'::text
            ELSE 'erro'::text
        END AS "Estado do Trânsito"
   FROM public.sentido2_last_10
  GROUP BY sentido2_last_10."Velocidade Media", sentido2_last_10."Contagem", sentido2_last_10."Velocidade Maxima", sentido2_last_10."Velocidade Minima"
  WITH NO DATA;


ALTER TABLE public.estatisticas_sentido_2 OWNER TO postgres;

--
-- Name: historico_sentido_1; Type: MATERIALIZED VIEW; Schema: public; Owner: postgres
--

CREATE MATERIALIZED VIEW public.historico_sentido_1 AS
 SELECT dadosobjetos."timestamp" AS "Data Hora",
    dadosobjetos.velocidade AS "Velocidade"
   FROM public.dadosobjetos
  WHERE ((dadosobjetos.id_type = ANY (ARRAY[2, 3, 4])) AND ((dadosobjetos.sentido)::text = '1'::text))
  WITH NO DATA;


ALTER TABLE public.historico_sentido_1 OWNER TO postgres;

--
-- Name: historico_sentido_2; Type: MATERIALIZED VIEW; Schema: public; Owner: postgres
--

CREATE MATERIALIZED VIEW public.historico_sentido_2 AS
 SELECT dadosobjetos."timestamp" AS "Data Hora",
    abs(dadosobjetos.velocidade) AS "Velocidade"
   FROM public.dadosobjetos
  WHERE ((dadosobjetos.id_type = ANY (ARRAY[2, 3, 4])) AND ((dadosobjetos.sentido)::text = '0'::text))
  WITH NO DATA;


ALTER TABLE public.historico_sentido_2 OWNER TO postgres;

--
-- Name: login; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.login (
    "user" character varying(255) NOT NULL,
    pass character varying(255) NOT NULL
);


ALTER TABLE public.login OWNER TO postgres;

--
-- Name: radar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.radar (
    id integer NOT NULL,
    nome character varying NOT NULL,
    "localização" character varying(255) NOT NULL,
    num_vias integer NOT NULL,
    num_sentido integer NOT NULL
);


ALTER TABLE public.radar OWNER TO postgres;

--
-- Name: type_entidades; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.type_entidades (
    id integer NOT NULL,
    nome character varying(255) NOT NULL
);


ALTER TABLE public.type_entidades OWNER TO postgres;

--
-- Name: type_objeto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.type_objeto (
    id_type integer NOT NULL,
    nome character varying(255) NOT NULL
);


ALTER TABLE public.type_objeto OWNER TO postgres;

--
-- Name: velocidades_maxima_e_minima_sentido_1; Type: MATERIALIZED VIEW; Schema: public; Owner: postgres
--

CREATE MATERIALIZED VIEW public.velocidades_maxima_e_minima_sentido_1 AS
 SELECT max(abs(historico_sentido_1."Velocidade")) AS "Velocidade Maxima",
    min(abs(historico_sentido_1."Velocidade")) AS "Velocidade Minima"
   FROM public.historico_sentido_1
  WITH NO DATA;


ALTER TABLE public.velocidades_maxima_e_minima_sentido_1 OWNER TO postgres;

--
-- Name: velocidades_maxima_e_minima_sentido_2; Type: MATERIALIZED VIEW; Schema: public; Owner: postgres
--

CREATE MATERIALIZED VIEW public.velocidades_maxima_e_minima_sentido_2 AS
 SELECT max(abs(historico_sentido_2."Velocidade")) AS "Velocidade Maxima",
    min(abs(historico_sentido_2."Velocidade")) AS "Velocidade Minima"
   FROM public.historico_sentido_2
  WITH NO DATA;


ALTER TABLE public.velocidades_maxima_e_minima_sentido_2 OWNER TO postgres;

--
-- Data for Name: dadosobjetos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dadosobjetos (id, "timestamp", velocidade, sentido, id_type, id_radar) FROM stdin;
\.
COPY public.dadosobjetos (id, "timestamp", velocidade, sentido, id_type, id_radar) FROM '$$PATH$$/3146.dat';

--
-- Data for Name: entidades; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.entidades (id, nome, "user", mail, type_entidadeid) FROM stdin;
\.
COPY public.entidades (id, nome, "user", mail, type_entidadeid) FROM '$$PATH$$/3145.dat';

--
-- Data for Name: estado; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.estado (id, velodade, "descrição") FROM stdin;
\.
COPY public.estado (id, velodade, "descrição") FROM '$$PATH$$/3147.dat';

--
-- Data for Name: login; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.login ("user", pass) FROM stdin;
\.
COPY public.login ("user", pass) FROM '$$PATH$$/3141.dat';

--
-- Data for Name: radar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.radar (id, nome, "localização", num_vias, num_sentido) FROM stdin;
\.
COPY public.radar (id, nome, "localização", num_vias, num_sentido) FROM '$$PATH$$/3142.dat';

--
-- Data for Name: type_entidades; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.type_entidades (id, nome) FROM stdin;
\.
COPY public.type_entidades (id, nome) FROM '$$PATH$$/3144.dat';

--
-- Data for Name: type_objeto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.type_objeto (id_type, nome) FROM stdin;
\.
COPY public.type_objeto (id_type, nome) FROM '$$PATH$$/3143.dat';

--
-- Name: dadosobjetos dadosobjetos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dadosobjetos
    ADD CONSTRAINT dadosobjetos_pkey PRIMARY KEY (id);


--
-- Name: entidades entidades_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entidades
    ADD CONSTRAINT entidades_pkey PRIMARY KEY (id);


--
-- Name: estado estado_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado
    ADD CONSTRAINT estado_pkey PRIMARY KEY (id);


--
-- Name: login login_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login
    ADD CONSTRAINT login_pkey PRIMARY KEY ("user");


--
-- Name: radar radar_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.radar
    ADD CONSTRAINT radar_pkey PRIMARY KEY (id);


--
-- Name: type_entidades type_entidades_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.type_entidades
    ADD CONSTRAINT type_entidades_pkey PRIMARY KEY (id);


--
-- Name: type_objeto type_objeto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.type_objeto
    ADD CONSTRAINT type_objeto_pkey PRIMARY KEY (id_type);


--
-- Name: entidades entidades; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entidades
    ADD CONSTRAINT entidades FOREIGN KEY (type_entidadeid) REFERENCES public.type_entidades(id);


--
-- Name: dadosobjetos id_radar; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dadosobjetos
    ADD CONSTRAINT id_radar FOREIGN KEY (id_radar) REFERENCES public.radar(id);


--
-- Name: dadosobjetos id_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dadosobjetos
    ADD CONSTRAINT id_type FOREIGN KEY (id_type) REFERENCES public.type_objeto(id_type);


--
-- Name: entidades user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entidades
    ADD CONSTRAINT "user" FOREIGN KEY ("user") REFERENCES public.login("user");


--
-- Name: sentido1_last_10; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: postgres
--

REFRESH MATERIALIZED VIEW public.sentido1_last_10;


--
-- Name: estatisticas_sentido_1; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: postgres
--

REFRESH MATERIALIZED VIEW public.estatisticas_sentido_1;


--
-- Name: sentido2_last_10; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: postgres
--

REFRESH MATERIALIZED VIEW public.sentido2_last_10;


--
-- Name: estatisticas_sentido_2; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: postgres
--

REFRESH MATERIALIZED VIEW public.estatisticas_sentido_2;


--
-- Name: historico_sentido_1; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: postgres
--

REFRESH MATERIALIZED VIEW public.historico_sentido_1;


--
-- Name: historico_sentido_2; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: postgres
--

REFRESH MATERIALIZED VIEW public.historico_sentido_2;


--
-- Name: velocidades_maxima_e_minima_sentido_1; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: postgres
--

REFRESH MATERIALIZED VIEW public.velocidades_maxima_e_minima_sentido_1;


--
-- Name: velocidades_maxima_e_minima_sentido_2; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: postgres
--

REFRESH MATERIALIZED VIEW public.velocidades_maxima_e_minima_sentido_2;


--
-- PostgreSQL database dump complete
--

